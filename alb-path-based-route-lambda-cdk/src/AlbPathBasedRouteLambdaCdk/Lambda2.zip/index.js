exports.handler = async (event) => {
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Service2!!!!'),
        headers: {
            'Content-Type': 'application/json'
        }
    };

    return response;
};