import json
import boto3
import random
import base64
import io
from PIL import Image
import os

def create_payload_im(prompt, negative_prompt=None):
    text_to_image_params = {
        "text": prompt
    }

    # Only include negativeText if provided and non-empty
    if negative_prompt:
        text_to_image_params["negativeText"] = negative_prompt

    payload = {
        "textToImageParams": text_to_image_params,
        "taskType": "TEXT_IMAGE",
        "imageGenerationConfig": {
            "numberOfImages": 1,
            "quality": "standard",
            "cfgScale": 8.0,
            "seed": random.randint(0, 2147483647)
        }
    }

    return json.dumps(payload)

def invoke_endpoint_br(payload):
    model_id = "amazon.nova-canvas-v1:0"
    bedrock = boto3.client(service_name='bedrock-runtime')
    response = bedrock.invoke_model(
        modelId=model_id,
        body=payload
    )
    response_body = json.loads(response.get("body").read())
    return response_body

def upload_file_s3(path, file_name, bucket):
    s3_client = boto3.client('s3')
    s3_client.upload_file(path, bucket, file_name)
    return True

def save_base64_as_png(base64_string, resize_to=None):
    imgdata = base64.b64decode(base64_string)
    image = Image.open(io.BytesIO(imgdata))
    if resize_to:
        image = image.resize(resize_to)
    file_name = f'image-{random.randint(0,1000)}.png'
    path = '/tmp/' + file_name
    image.save(path)
    return path, file_name

def handler(event, context):
    body = json.loads(event.get('body', '{}'))
    prompt = body.get('prompt', 'Default prompt here')
    negative_prompt = body.get('negative_prompt', None)  # Optional

    # Create payload
    payload = create_payload_im(prompt, negative_prompt)

    # Call Nova Canvas
    response = invoke_endpoint_br(payload)

    # Extract and save image
    image_base64 = response["images"][0]
    path, file_name = save_base64_as_png(image_base64)

    # Upload to S3
    upload_file_s3(path=path, file_name=file_name, bucket=os.environ['BUCKET'])

    return {
        'statusCode': 200,
        'body': json.dumps({
            'generated-image': file_name
        })
    }
