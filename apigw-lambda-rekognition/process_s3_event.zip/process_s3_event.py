import json
import os
import boto3
s3 = boto3.client('s3')
rekognition = boto3.client('rekognition')
sns = boto3.client('sns')
def lambda_handler(event, context):
    print(event)
    topic_arn = os.environ['SNS_TOPIC_ARN']
    # Get the bucket name and object key from the S3 event
    bucket = event['Records'][0]['s3']['bucket']['name']
    print("Bucket: " +  bucket)
    key = event['Records'][0]['s3']['object']['key']
    print("Object: " +  key)
    # Detect moderation labels in the image
    response = rekognition.detect_moderation_labels(
        Image={
            'S3Object': {
                'Bucket': bucket,
                'Name': key
            }
        },
        MinConfidence=70  # Adjust the minimum confidence level as needed
    )
    # Check if any moderation labels were detected
    labels = response.get('ModerationLabels', [])
    if labels:
        # Inappropriate content detected
        content_status = 'INAPPROPRIATE'
        message = f"Inappropriate content detected in image '{key}'"
        print(message)
        for label in labels:
            print(f"Label: {label['Name']}, Confidence: {label['Confidence']}")
        # Send email notification to the admin
        subject = 'Inappropriate Content Detected'
        body = f'{message}\n\nDetected Moderation Labels:\n'
        for label in labels:
            body += f"Label: {label['Name']}, Confidence: {label['Confidence']}\n"
        sns.publish(
            TopicArn=topic_arn,  # Replace with your SNS topic ARN
            Message=body,
            Subject=subject
        )
    else:
        # No inappropriate content detected
        content_status = 'SAFE'
        message = f"Image '{key}' does not contain inappropriate content"
        print(message)
    # Return the response
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': message,
            'contentStatus': content_status,
            'moderationLabels': [
                {'name': label['Name'], 'confidence': label['Confidence']} for label in labels
            ]
        })
    }