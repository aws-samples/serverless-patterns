import json
import os
import boto3
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
region = os.environ['AWS_REGION']
s3_client = boto3.client('s3', endpoint_url='https://s3.{0}.amazonaws.com'.format(region))
def lambda_handler(event, context):
    bucket_name = os.environ['BUCKET_NAME']
    expiration = 3600  # URL expiration time in seconds
    # Get the object name and content type from the event
    if (event['body']) and (event['body'] is not None):
        body = json.loads(event['body'])
    object_name = body.get('object_name')
    content_type = body.get('content_type', 'application/octet-stream')  # Default content type
    if not object_name:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Object name is required'})
        }
    try:
        presigned_url = s3_client.generate_presigned_url('put_object',
                                                         Params={'Bucket': bucket_name,
                                                                 'Key': object_name,
                                                                 'ContentType': content_type},
                                                         ExpiresIn=expiration)
        return {
            'statusCode': 200,
            'body': json.dumps({'presigned_url': presigned_url})
        }
    except Exception as e:
        logger.error(f'Error generating presigned URL: {str(e)}')
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }