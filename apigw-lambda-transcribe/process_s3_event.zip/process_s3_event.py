import json
import boto3
import os
import time
import urllib.parse
import re

transcribe = boto3.client('transcribe')
s3 = boto3.client('s3')

output_bucket = os.environ['OUTPUT_BUCKET']


def lambda_handler(event, context):
    try:
        for record in event['Records']:
            # Get S3 Object Info
            bucket_name = record['s3']['bucket']['name']
            key = urllib.parse.unquote_plus(record['s3']['object']['key'])

            # Verify object exists
            try:
                s3.head_object(Bucket=bucket_name, Key=key)
                print(f"Object exists: s3://{bucket_name}/{key}")
            except Exception as e:
                print(f"Error checking object: {str(e)}")
                raise Exception(f"Object does not exist: s3://{bucket_name}/{key}")

            # Generate Transcription Job Name
            base_name = re.sub(r'[^0-9a-zA-Z._-]', '_', key.split('.')[0])
            job_name = base_name + str(int(time.time()))
            job_name = job_name[0:199] if len(job_name) >= 200 else job_name

            # Construct the MediaFileUri without encoding
            media_uri = f's3://{bucket_name}/{key}'
            
            print(f"Job name: {job_name}")
            print(f"MediaFileUri: {media_uri}")

            # Start Transcription Job
            response = transcribe.start_transcription_job(
                TranscriptionJobName=job_name,
                IdentifyLanguage=True,
                Media={
                    'MediaFileUri': media_uri
                },
                OutputBucketName=output_bucket,
                OutputKey=job_name + '.json'
            )

        return {
            'statusCode': 200,
            'body': json.dumps(response['TranscriptionJob']['TranscriptionJobName'])
        }

    except Exception as e:
        print('Error')
        print(str(e))
        return {
            'statusCode': 500,
            'body': str(e)
        }
