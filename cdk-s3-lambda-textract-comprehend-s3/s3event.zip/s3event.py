import boto3
import logging
import time

# Configure logging
LOG = logging.getLogger()
LOG.setLevel(logging.INFO)  # Set to DEBUG level for detailed logging

def process_comprehend(text):
    comprehend_client = boto3.client('comprehend')

    # Detect PII entities in the text
    pii_entities_response = comprehend_client.detect_pii_entities(Text=text, LanguageCode='en')
    entities = []

    for entity in pii_entities_response['Entities']:
        if entity['Score'] > 0.7:  # Check if the score is greater than 70
            pii_entity = {
                "Type": entity['Type'],
                "Score": entity['Score'],
                "BeginOffset": entity['BeginOffset'],
                "EndOffset": entity['EndOffset']
            }
            entities.append(pii_entity)

    return entities

def get_textract_results(job_id):
    textract_client = boto3.client('textract')

    while True:
        response = textract_client.get_document_text_detection(JobId=job_id)
        status = response['JobStatus']
        
        if status == 'SUCCEEDED':
            return response
        elif status == 'FAILED':
            raise Exception("Textract job failed")
        
        time.sleep(5)  # Wait for 5 seconds before checking again
        
def move_to_invalid_bucket(bucket_name, object_key):
    s3 = boto3.client('s3')
    destination_key = f"invalid-docs-folder/{object_key}"
    destination_bucket = 'invalid-docs-bucket'
    try:
        s3.copy_object(
            Bucket=destination_bucket,
            CopySource={'Bucket': bucket_name, 'Key': object_key},
            Key=destination_key
        )
        LOG.info(f"PDF file copied to S3 bucket: {destination_bucket}/{destination_key}")

        # Delete the original object from docs-landing-bucket
        s3.delete_object(
            Bucket=bucket_name,
            Key=object_key
        )
        LOG.info(f"Original object deleted from S3 bucket: {bucket_name}/{object_key}")

    except Exception as e:
        LOG.error(f"Error copying or deleting file: {str(e)}")
        
def lambda_handler(event, context):
    
    
    # Extract S3 bucket, key, and file name from the incoming event
    records = event.get('Records', [])
    if not records:
        LOG.error("No records found in the event.")
        return {
            "error_message": "No records found in the event"
        }

    for record in records:
        s3_info = record.get('s3', {})
        bucket_name = s3_info.get('bucket', {}).get('name')
        object_key = s3_info.get('object', {}).get('key')

        LOG.info(f"File name is {object_key}")

    # Call Amazon Textract
    textract_client = boto3.client('textract')

    response = None  # Initialize response with a default value

    try:
        response = textract_client.start_document_text_detection(
            DocumentLocation={"S3Object": {"Bucket": bucket_name, "Name": object_key}}
        )
        job_id = response['JobId']
        LOG.info(f"Textract job started with JobId: {job_id}")
    except textract_client.exceptions.UnsupportedDocumentException as e:
        LOG.error(f"Unsupported document format: {str(e)}")

        move_to_invalid_bucket(bucket_name, object_key)
        return {
            "error_message": "Unsupported document format"
        }
    except textract_client.exceptions.InvalidS3ObjectException as e:
        LOG.error(f"Unsupported Format/Object type detected. Textract can't process the File. Please try with a new file: {str(e)}")
        
        #LOG.info(f"Moving the PDF to invalid-docs")
        # Move the PDF to the invalid-docs-bucket
        move_to_invalid_bucket(bucket_name, object_key)
        return {
            "error_message": "Invalid S3 object for textract"
        }

    if response is not None:
        # Wait for Textract job to complete and get results
        textract_results = get_textract_results(job_id)
        
        # Extract text blocks from Textract results
        blocks = textract_results["Blocks"]
        text_blocks = [block for block in blocks if block["BlockType"] == "LINE"]

        # Extract text from text blocks
        text = ' '.join([block["Text"] for block in text_blocks])

        LOG.info("Text is %s", text)

       # Process extracted text using Amazon Comprehend
        comprehend_results = process_comprehend(text)
        print("Comprehend results:", comprehend_results)
        
        # Check if "IN_AADHAAR" entity is identified
        if any(entity['Type'] == 'IN_AADHAAR' for entity in comprehend_results):
            LOG.info("Document is a valid Aadhaar or it contains Aadhaar data.")
            print("Document is a valid Aadhaar or it contains Aadhaar data.")
            
            # Copy the PDF to the valid-docs-bucket
            s3 = boto3.client('s3')
            destination_key = f"aadhaar-docs-folder/{object_key}"
            destination_bucket = 'valid-docs-bucket'
            try:
                s3.copy_object(
                    Bucket=destination_bucket,
                    CopySource={'Bucket': bucket_name, 'Key': object_key},
                    Key=destination_key
                )
                LOG.info(f"PDF file copied to S3 bucket: {destination_bucket}/{destination_key}")

                # Delete the original object from docs-landing-bucket
                s3.delete_object(
                    Bucket=bucket_name,
                    Key=object_key
                )
                LOG.info(f"Original object deleted from S3 bucket: {bucket_name}/{object_key}")

            except Exception as e:
                LOG.error(f"Error copying or deleting file: {str(e)}")
            
        elif any(entity['Type'] == 'PASSPORT_NUMBER' for entity in comprehend_results):
            LOG.info("Document is a valid Passport or it contains Passport data.")
            print("Document is a valid Passport or it contains Passport data.")
            
            # Copy the PDF to the valid-docs-bucket
            s3 = boto3.client('s3')
            destination_key = f"passport-docs-folder/{object_key}"
            destination_bucket = 'valid-docs-bucket'
            try:
                s3.copy_object(
                    Bucket=destination_bucket,
                    CopySource={'Bucket': bucket_name, 'Key': object_key},
                    Key=destination_key
                )
                LOG.info(f"PDF file copied to S3 bucket: {destination_bucket}/{destination_key}")

                # Delete the original object from docs-landing-bucket
                s3.delete_object(
                    Bucket=bucket_name,
                    Key=object_key
                )
                LOG.info(f"Original object deleted from S3 bucket: {bucket_name}/{object_key}")

            except Exception as e:
                LOG.error(f"Error copying or deleting file: {str(e)}")

        elif any(entity['Type'] == 'IN_PERMANENT_ACCOUNT_NUMBER' for entity in comprehend_results):
            LOG.info("Document is a valid PAN or it contains PAN data.")
            print("Document is a valid PAN or it contains PAN data.")
            
            # Copy the PDF to the valid-docs-bucket
            s3 = boto3.client('s3')
            destination_key = f"pan-docs-folder/{object_key}"
            destination_bucket = 'valid-docs-bucket'
            try:
                s3.copy_object(
                    Bucket=destination_bucket,
                    CopySource={'Bucket': bucket_name, 'Key': object_key},
                    Key=destination_key
                )
                LOG.info(f"PDF file copied to S3 bucket: {destination_bucket}/{destination_key}")

                # Delete the original object from docs-landing-bucket
                s3.delete_object(
                    Bucket=bucket_name,
                    Key=object_key
                )
                LOG.info(f"Original object deleted from S3 bucket: {bucket_name}/{object_key}")

            except Exception as e:
                LOG.error(f"Error copying or deleting file: {str(e)}")        

        elif any(entity['Type'] == 'IN_NREGA' for entity in comprehend_results):
            LOG.info("Document is a valid IN_NREGA or it contains NREGA data.")
            print("Document is a valid IN_NREGA or it contains NREGA data.")
            
            # Copy the PDF to the valid-docs-bucket
            s3 = boto3.client('s3')
            destination_key = f"nrega-docs-folder/{object_key}"
            destination_bucket = 'valid-docs-bucket'
            try:
                s3.copy_object(
                    Bucket=destination_bucket,
                    CopySource={'Bucket': bucket_name, 'Key': object_key},
                    Key=destination_key
                )
                LOG.info(f"PDF file copied to S3 bucket: {destination_bucket}/{destination_key}")

                # Delete the original object from docs-landing-bucket
                s3.delete_object(
                    Bucket=bucket_name,
                    Key=object_key
                )
                LOG.info(f"Original object deleted from S3 bucket: {bucket_name}/{object_key}")

            except Exception as e:
                LOG.error(f"Error copying or deleting file: {str(e)}")

        elif any(entity['Type'] == 'DRIVER_ID' for entity in comprehend_results):
            LOG.info("Document is a valid DRIVER_ID or it contains Driver ID.")
            print("Document is a valid DRIVER_ID or it contains Driver ID.")
            
            # Copy the PDF to the valid-docs-bucket
            s3 = boto3.client('s3')
            destination_key = f"driverid-docs-folder/{object_key}"
            destination_bucket = 'valid-docs-bucket'
            try:
                s3.copy_object(
                    Bucket=destination_bucket,
                    CopySource={'Bucket': bucket_name, 'Key': object_key},
                    Key=destination_key
                )
                LOG.info(f"PDF file copied to S3 bucket: {destination_bucket}/{destination_key}")

                # Delete the original object from docs-landing-bucket
                s3.delete_object(
                    Bucket=bucket_name,
                    Key=object_key
                )
                LOG.info(f"Original object deleted from S3 bucket: {bucket_name}/{object_key}")

            except Exception as e:
                LOG.error(f"Error copying or deleting file: {str(e)}")                

        else:
            LOG.info("Document is not a valid Govt ID. Skipping processing.")
            print("Document is not a valid Govt ID. Skipping processing.")
            
            # Copy the PDF to the invalid-docs-bucket
            s3 = boto3.client('s3')
            destination_key = f"invalid-docs-folder/{object_key}"
            destination_bucket = 'invalid-docs-bucket'
            try:
                s3.copy_object(
                    Bucket=destination_bucket,
                    CopySource={'Bucket': bucket_name, 'Key': object_key},
                    Key=destination_key
                )
                LOG.info(f"PDF file copied to S3 bucket: {destination_bucket}/{destination_key}")

                # Delete the original object from docs-landing-bucket
                s3.delete_object(
                    Bucket=bucket_name,
                    Key=object_key
                )
                LOG.info(f"Original object deleted from S3 bucket: {bucket_name}/{object_key}")

            except Exception as e:
                LOG.error(f"Error copying or deleting file: {str(e)}")
        # Return the Comprehend results
        return {
            "comprehend_results": comprehend_results
        }
        
    else:
        LOG.info("Response is None. Unable to process document.")
        return {
            "error_message": "Unable to process document"
        }