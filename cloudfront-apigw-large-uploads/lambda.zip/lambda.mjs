// create constant variable with value 300
const MAX_FILE_SIZE = 300;
const LARGE_UPLOAD_ORIGIN = "echo.free.beeceptor.com"; // Update this to the URL of the large file upload server

export const handler = async (event) => {
    const request = event.Records[0].cf.request;
    const headers = request.headers;
    const origin = event.Records[0].cf.request.origin;

    // You can view the request before any modification in CloudWatch Logs for the Lambda@Edge function by uncommenting the following line.
    // console.log(`Request BEFORE: ` + JSON.stringify(request));

    if (request.method === 'POST') {
        if (headers['content-length'] && parseInt(headers['content-length'][0].value) < MAX_FILE_SIZE ) {
            console.log(`Request size less than: ` + MAX_FILE_SIZE); 
        } else {
            console.log(`Request has no content-length or request size is greater than: ` + MAX_FILE_SIZE);
            origin.custom.domainName = LARGE_UPLOAD_ORIGIN;
            request.headers.host[0].value = LARGE_UPLOAD_ORIGIN;
            request.uri = '/'; // You can use this to modify the request URI to the upload server
        }
    }

    // You can view the request after modifications in CloudWatch Logs for the Lambda@Edge function by uncommenting the following line.
    // console.log(`Request AFTER: ` + JSON.stringify(request));
    return request;
};