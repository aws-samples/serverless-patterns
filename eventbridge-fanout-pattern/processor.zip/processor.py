import json
import logging
from datetime import datetime, timezone

logger = logging.getLogger()
logger.setLevel(logging.INFO)


#Task Handlers

def hourly_job(detail, context):
    logger.info("Running hourly job...")
    result = {
        "recordsProcessed": 42,
        "duration": "3.2s",
    }
    logger.info("Hourly job complete: %s", json.dumps(result))
    return result


def daily_cleanup(detail, context):
    logger.info("Running daily cleanup...")
    result = {
        "deletedRecords": 156,
        "freedSpaceMB": 23,
    }
    logger.info("Cleanup complete: %s", json.dumps(result))
    return result


def manual_test(detail, context):
    logger.info("Manual test event received")
    return {"echo": detail}


def integration_test(detail, context):
    logger.info("Integration test event received")
    return {"echo": detail}


#Task Registry

TASKS = {
    "hourly-job": hourly_job,
    "daily-cleanup": daily_cleanup,
    "manual-test": manual_test,
    "integration-test": integration_test,
}


#Main Handler

def lambda_handler(event, context):
    logger.info("Event received:\n%s", json.dumps(event, indent=2))

    detail = event.get("detail", {})
    task_id = detail.get("taskId", "unknown")

    logger.info("Source: %s", event.get("source"))
    logger.info("Type:   %s", event.get("detail-type"))
    logger.info("Task:   %s", task_id)
    logger.info("Time:   %s", event.get("time"))

    # Route to task
    task_fn = TASKS.get(task_id)

    if not task_fn:
        known = ", ".join(TASKS.keys())
        msg = f'Unknown taskId: "{task_id}". Known tasks: {known}'
        logger.warning(msg)
        return {"statusCode": 400, "body": msg}

    try:
        result = task_fn(detail, context)

        response = {
            "statusCode": 200,
            "taskId": task_id,
            "result": result,
            "processedAt": datetime.now(timezone.utc).isoformat(),
            "requestId": context.aws_request_id,
        }
        logger.info("Response:\n%s", json.dumps(response, indent=2))
        return response

    except Exception as e:
        logger.error('Task "%s" failed: %s', task_id, str(e), exc_info=True)
        raise