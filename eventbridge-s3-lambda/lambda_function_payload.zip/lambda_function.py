import json
import os
import boto3
sns_client = boto3.client('sns')
def lambda_handler(event, context):
    topic_arn = os.environ['SNS_TOPIC_ARN']
    # Log the received event
    print("Received event: " + json.dumps(event, indent=2))
    # Extract the CloudTrail event details
    cloudtrail_event = event['detail']
    # Prepare the message
    message = json.dumps(cloudtrail_event, indent=2)
    # Publish the message to the SNS topic
    response = sns_client.publish(
        TopicArn=topic_arn,
        Message=message,
        Subject='S3 Bucket Created Event'
    )
    return {
        'statusCode': 200,
        'body': json.dumps('SNS message sent successfully!')
    }