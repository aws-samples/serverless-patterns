import json

def lambda_handler(event, context):
    
    lambda_list = event['Function_ARN_List_existing']
    
    #ListFunctions API call response loop & appending Item to json 
    for item in event['ListFunctions_output']['Functions']:
        lambda_list["lambda_arn_list_combined"].append({'ARN':item['FunctionArn']})

    #checking if NextMarker exists or not in the event object
    if 'NextMarker' not in event['ListFunctions_output']:
        NextMarkerinput= None
        NextMarkercheck = 'false'
    else:
        NextMarkerinput=event['ListFunctions_output']['NextMarker']
        NextMarkercheck = 'true'

    
    return {
        'statusCode': 200,
        'NextMarkercheck': NextMarkercheck,
        'NextMarker' : NextMarkerinput,
        'Function_ARN_List_existing' : lambda_list
    }
