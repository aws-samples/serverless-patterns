import json
import logging
import os
import re

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

TABLE_NAME = os.environ["TABLE_NAME"]
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)

# Simple allowlist for tenant IDs — alphanumeric, hyphens, underscores.
TENANT_ID_PATTERN = re.compile(r"^[\w\-]{1,100}$")


def lambda_handler(event, context):
    """
    Tenant-isolated Lambda handler.

    * The Lambda runtime guarantees a dedicated execution environment per
      tenant (`PER_TENANT` isolation mode).
    * Each tenant's counter is stored in its own DynamoDB row keyed by
      ``tenant_id``, so even at the data layer there is no sharing.
    """
    try:
        if not isinstance(event, dict):
            return _error(400, "Bad Request", "Invalid request format")

        logger.info(
            "Processing isolated request — Method: %s, Path: %s",
            event.get("httpMethod", "UNKNOWN"),
            event.get("path", "UNKNOWN"),
        )

        http_method = event.get("httpMethod", "")
        if not http_method:
            return _error(400, "Bad Request", "Missing HTTP method in request")
        if http_method != "GET":
            return _error(
                405,
                "Method Not Allowed",
                f"HTTP method {http_method} is not supported. Only GET requests are allowed.",
            )

        # ── Resolve tenant ID from Lambda context ───────────────────
        tenant_id = getattr(context, "tenant_id", None)

        if not tenant_id:
            logger.error("Missing tenant_id in Lambda context")
            return _error(
                400,
                "Missing Tenant ID",
                "Tenant ID is required. Ensure the x-tenant-id header is provided.",
            )

        tenant_id = tenant_id.strip()

        if not TENANT_ID_PATTERN.match(tenant_id):
            logger.error("Invalid tenant ID format: %s", tenant_id)
            return _error(
                400,
                "Invalid Tenant ID",
                "Tenant ID must be 1-100 alphanumeric, hyphen, or underscore characters.",
            )

        # ── Atomic per-tenant increment ─────────────────────────────
        response = table.update_item(
            Key={"tenant_id": tenant_id},
            UpdateExpression="SET #c = if_not_exists(#c, :zero) + :inc",
            ExpressionAttributeNames={"#c": "counter"},
            ExpressionAttributeValues={":zero": 0, ":inc": 1},
            ReturnValues="UPDATED_NEW",
        )
        counter = int(response["Attributes"]["counter"])

        logger.info("Tenant '%s' — isolated counter now at %d", tenant_id, counter)

        body = {
            "counter": counter,
            "tenant_id": tenant_id,
            "isolation_enabled": True,
            "message": f"Counter incremented for tenant {tenant_id}",
        }

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Cache-Control": "no-cache",
            },
            "body": json.dumps(body),
        }

    except ClientError as exc:
        logger.error("DynamoDB error: %s", exc.response["Error"]["Message"], exc_info=True)
        return _error(500, "Internal Server Error", "Database error while updating counter")
    except Exception:
        logger.error("Unexpected error processing isolated request", exc_info=True)
        return _error(500, "Internal Server Error", "An unexpected error occurred")


def _error(status_code, error_type, message):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Cache-Control": "no-cache",
        },
        "body": json.dumps(
            {"error": error_type, "message": message, "statusCode": status_code}
        ),
    }