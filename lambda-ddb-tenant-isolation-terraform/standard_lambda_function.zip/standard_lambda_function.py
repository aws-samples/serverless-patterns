import json
import logging
import os

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

TABLE_NAME = os.environ["TABLE_NAME"]
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)

# The single partition key every tenant shares — the core of the problem.
SHARED_KEY = "SHARED"


def lambda_handler(event, context):
    """
    Standard Lambda handler WITHOUT tenant isolation.

    All tenants share a single DynamoDB row, so every call — regardless
    of which tenant makes it — increments the same counter.  This is the
    multi-tenant anti-pattern this demo exists to highlight.
    """
    try:
        if not isinstance(event, dict):
            return _error(400, "Bad Request", "Invalid request format")

        headers = event.get("headers", {}) or {}
        tenant_id_from_header = (
            headers.get("x-tenant-id")
            or headers.get("Tenant-Id")
            or headers.get("TENANT-ID")
        )

        logger.info(
            "Processing standard request — Method: %s, Path: %s, Tenant Header: %s",
            event.get("httpMethod", "UNKNOWN"),
            event.get("path", "UNKNOWN"),
            tenant_id_from_header,
        )

        http_method = event.get("httpMethod", "")
        if not http_method:
            return _error(400, "Bad Request", "Missing HTTP method in request")
        if http_method != "GET":
            return _error(
                405,
                "Method Not Allowed",
                f"HTTP method {http_method} is not supported. Only GET requests are allowed.",
            )

        # ── Atomic increment on the SHARED row ──────────────────────
        response = table.update_item(
            Key={"pk": SHARED_KEY},
            UpdateExpression="SET #c = if_not_exists(#c, :zero) + :inc",
            ExpressionAttributeNames={"#c": "counter"},
            ExpressionAttributeValues={":zero": 0, ":inc": 1},
            ReturnValues="UPDATED_NEW",
        )
        counter = int(response["Attributes"]["counter"])

        if tenant_id_from_header:
            logger.warning(
                "PROBLEM: Tenant '%s' is using SHARED counter value %d! "
                "This demonstrates data leakage between tenants.",
                tenant_id_from_header,
                counter,
            )
        else:
            logger.info("Request without tenant header — shared counter: %d", counter)

        body = {
            "counter": counter,
            "tenant_id": tenant_id_from_header,
            "isolation_enabled": False,
            "message": (
                f"This function does NOT provide tenant isolation and every tenant reads and writes the same DynamoDB row. Incremented counter is shared across all the tenants"
            ),
        }

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Cache-Control": "no-cache",
            },
            "body": json.dumps(body),
        }

    except ClientError as exc:
        logger.error("DynamoDB error: %s", exc.response["Error"]["Message"], exc_info=True)
        return _error(500, "Internal Server Error", "Database error while updating counter")
    except Exception:
        logger.error("Unexpected error processing request", exc_info=True)
        return _error(500, "Internal Server Error", "An unexpected error occurred")


def _error(status_code, error_type, message):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Cache-Control": "no-cache",
        },
        "body": json.dumps(
            {"error": error_type, "message": message, "statusCode": status_code}
        ),
    }