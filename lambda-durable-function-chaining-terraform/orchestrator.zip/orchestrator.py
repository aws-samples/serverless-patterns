import json
import os
import logging
import boto3
from aws_durable_execution_sdk_python import DurableContext, durable_execution

logger = logging.getLogger()
logger.setLevel(logging.INFO)

lambda_client = boto3.client('lambda')


def call_lambda(function_arn, payload):
    """Invoke a regular Lambda function and return parsed response."""
    response = lambda_client.invoke(
        FunctionName=function_arn,
        InvocationType='RequestResponse',
        Payload=json.dumps(payload)
    )

    if 'FunctionError' in response:
        error_payload = json.loads(response['Payload'].read())
        raise RuntimeError(f"Function {function_arn} failed: {error_payload}")

    return json.loads(response['Payload'].read())


@durable_execution
def lambda_handler(event, context: DurableContext):
    step1_arn = os.environ['STEP1_FUNCTION_ARN']
    step2_arn = os.environ['STEP2_FUNCTION_ARN']
    step3_arn = os.environ['STEP3_FUNCTION_ARN']

    logger.info("Orchestrator invoked with event: %s", json.dumps(event, default=str))

    # Step 1 — note the _ parameter to accept the argument context.step() passes
    result1 = context.step(
        lambda _: call_lambda(step1_arn, event),
        name='step1-add'
    )
    logger.info("STEP1 result: %s", json.dumps(result1, default=str))

    # Step 2
    result2 = context.step(
        lambda _: call_lambda(step2_arn, result1),
        name='step2-transform'
    )
    logger.info("STEP2 result: %s", json.dumps(result2, default=str))

    # Step 3
    result3 = context.step(
        lambda _: call_lambda(step3_arn, result2),
        name='step3-finalize'
    )
    logger.info("STEP3 result: %s", json.dumps(result3, default=str))

    response = {
        'workflow': 'completed',
        'input': event,
        'output': result3
    }
    logger.info("Final response: %s", json.dumps(response, default=str))
    return response