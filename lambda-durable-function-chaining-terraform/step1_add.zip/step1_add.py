def lambda_handler(event, context):
    """Step 1: Add initial data fields to the input."""
    print("Execution reached step1: Printing event ")
    print(event)
    print("==============")
    response = {
        'id': event.get('id', 'unknown'),
        'name': event.get('name', 'default'),
        'step1_completed': True,
        'step1_value': event.get('value', 0) + 10
    }
    print(f"Step 1 response: {response}")
    return response