def lambda_handler(event, context):
    """Step 2: Transform and enrich the data."""
    print("Execution reached step2: Printing event ")
    print(event)
    print("==============")

    if not event:
        print(f"Step 2 response: {event}")
        return event

    response = {
        **event,
        'step2_completed': True,
        'step2_value': event.get('step1_value', 0) * 2,
        'transformed_name': event.get('name', '').upper()
    }
    print(f"Step 2 response: {response}")
    return response