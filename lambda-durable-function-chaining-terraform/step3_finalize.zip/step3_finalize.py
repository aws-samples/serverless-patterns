def lambda_handler(event, context):
    """Step 3: Finalize the data with status."""
    print("Execution reached step3")

    if not event:
        print(f"Step 3 response: {event}")
        return event

    response = {
        **event,
        'step3_completed': True,
        'status': 'COMPLETED',
        'final_value': event.get('step2_value', 0) + 5
    }
    print(f"Step 3 response: {response}")
    return response