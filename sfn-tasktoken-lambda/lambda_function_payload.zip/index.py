import json
import boto3
client = boto3.client('stepfunctions')
def lambda_handler(event, context):
    print(event)
    message_body = json.loads(event['Records'][0]['body'])
    task_token = message_body['TaskToken']
    # Send success response to Step Functions
    response = client.send_task_success(
        taskToken=task_token,
        output='"Callback task completed successfully."'
    )
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }