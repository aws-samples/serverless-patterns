def lambda_handler(event, context):
    print("Hello Python! Hello Terraform!")

    return event
